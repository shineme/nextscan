/**
 * System Logs API
 * GET /api/logs - Get recent logs
 * GET /api/logs?since=timestamp - Get logs since timestamp
 * GET /api/logs?category=scanner - Filter by category
 * DELETE /api/logs - Clear all logs
 */

import { NextRequest, NextResponse } from 'next/server';
import logger, { LogCategory } from '@/lib/logger-service';
import db from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const since = searchParams.get('since');
    const category = searchParams.get('category') as LogCategory | null;
    const limit = parseInt(searchParams.get('limit') || '100');

    let logs;
    if (since) {
      logs = logger.getLogsSince(since, category || undefined);
    } else {
      logs = logger.getRecentLogs(limit, category || undefined);
    }

    return NextResponse.json({
      success: true,
      data: logs,
      count: logs.length
    });
  } catch (error) {
    console.error('Failed to get logs:', error);
    return NextResponse.json(
      { success: false, message: 'Failed to get logs' },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/logs - Clear all system logs
 */
export async function DELETE() {
  try {
    const stmt = db.prepare('DELETE FROM system_logs');
    const result = stmt.run();

    return NextResponse.json({
      success: true,
      deletedCount: result.changes,
      message: `Cleared ${result.changes} log entries`
    });
  } catch (error) {
    console.error('Failed to clear logs:', error);
    return NextResponse.json(
      { success: false, message: 'Failed to clear logs' },
      { status: 500 }
    );
  }
}
