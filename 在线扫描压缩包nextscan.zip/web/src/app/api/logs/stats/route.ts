/**
 * System Logs Statistics API
 * GET /api/logs/stats - Get log statistics
 */

import { NextResponse } from 'next/server';
import logger from '@/lib/logger-service';

export async function GET() {
  try {
    const stats = logger.getStats();

    return NextResponse.json({
      success: true,
      data: stats
    });
  } catch (error) {
    console.error('Failed to get log stats:', error);
    return NextResponse.json(
      { success: false, message: 'Failed to get log statistics' },
      { status: 500 }
    );
  }
}
