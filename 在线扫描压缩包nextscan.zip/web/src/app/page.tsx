import DashboardApp from '@/components/DashboardApp';

export default function Home() {
  return <DashboardApp />;
}
